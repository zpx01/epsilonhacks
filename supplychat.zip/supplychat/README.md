#SupplyChat

A simple prototype chatbot that utilizes inventory data from retialers and relays information to users in the general community upon request.

In the presence of COVID-19, it is crucial for the general community to obtain essential supplies. SupplyChat allows them to check inventories of nearby retailers and optimizes the search time for required supplies. Through this simple chatbot, users can find the items they need as soon as possible, allowing them to meet their urgent needs in these dangerous times.

